package com.example.archiveservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ArchiveserviceApplication {

	public static void main(String[] args) {
		SpringApplication.run(ArchiveserviceApplication.class, args);
	}

}
