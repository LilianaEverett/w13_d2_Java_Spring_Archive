package com.example.archiveservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ArchiveserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
